"use strict";

// ── Elementos del DOM ──────────────────────────────────────────────────────────
const btnCalcular   = document.getElementById("btnCalcular");
const inputPeso     = document.getElementById("peso");
const inputAltura   = document.getElementById("altura");
const resultGroup   = document.getElementById("resultGroup");
const imcValor      = document.getElementById("imcValor");
const imcCategoria  = document.getElementById("imcCategoria");
const barraIndicador = document.getElementById("barraIndicador");

// ── Categorías IMC ─────────────────────────────────────────────────────────────
// Según la OMS: <18.5 / 18.5-24.9 / 25-29.9 / >=30
const CATEGORIAS = [
  { min: 0,    max: 18.5,  label: "Bajo peso",  color: "#5bc4f5", posMin: 0,   posMax: 25  },
  { min: 18.5, max: 25,    label: "Normal",      color: "#4cde8c", posMin: 25,  posMax: 50  },
  { min: 25,   max: 30,    label: "Sobrepeso",   color: "#f5a623", posMin: 50,  posMax: 75  },
  { min: 30,   max: Infinity, label: "Obesidad", color: "#e8504a", posMin: 75,  posMax: 100 },
];

// ── Calcular posición de la barra (%) basada en el IMC ─────────────────────────
// Mapeamos: IMC 10 → 0%, IMC 18.5 → 25%, IMC 25 → 50%, IMC 30 → 75%, IMC 40+ → ~100%
function calcularPosicion(imc) {
  const puntos = [
    { imc: 10,  pos: 0   },
    { imc: 18.5,pos: 25  },
    { imc: 25,  pos: 50  },
    { imc: 30,  pos: 75  },
    { imc: 40,  pos: 100 },
  ];

  if (imc <= puntos[0].imc) return puntos[0].pos;
  if (imc >= puntos[puntos.length - 1].imc) return puntos[puntos.length - 1].pos;

  for (let i = 0; i < puntos.length - 1; i++) {
    const a = puntos[i];
    const b = puntos[i + 1];
    if (imc >= a.imc && imc <= b.imc) {
      const t = (imc - a.imc) / (b.imc - a.imc);
      return a.pos + t * (b.pos - a.pos);
    }
  }
  return 0;
}

// ── Obtener categoría según el IMC ────────────────────────────────────────────
function obtenerCategoria(imc) {
  return CATEGORIAS.find(c => imc >= c.min && imc < c.max) || CATEGORIAS[CATEGORIAS.length - 1];
}

// ── Marcar input con error ────────────────────────────────────────────────────
function marcarError(input) {
  input.classList.remove("input-error");
  // Forzar reflow para reiniciar la animación
  void input.offsetWidth;
  input.classList.add("input-error");
  input.addEventListener("input", () => input.classList.remove("input-error"), { once: true });
}

// ── Calcular IMC ──────────────────────────────────────────────────────────────
function calcularIMC() {
  const peso   = parseFloat(inputPeso.value);
  const altura = parseFloat(inputAltura.value);
  let hayError = false;

  // Validación
  if (!inputPeso.value || isNaN(peso) || peso <= 0 || peso > 500) {
    marcarError(inputPeso);
    hayError = true;
  }
  if (!inputAltura.value || isNaN(altura) || altura <= 0 || altura > 3) {
    marcarError(inputAltura);
    hayError = true;
  }
  if (hayError) return;

  // Cálculo
  const imc      = peso / (altura * altura);
  const imcRedon = imc.toFixed(2);
  const cat      = obtenerCategoria(imc);
  const posicion = calcularPosicion(imc);

  // Mostrar resultado
  imcValor.textContent      = imcRedon;
  imcCategoria.textContent  = cat.label;
  imcValor.style.color      = cat.color;
  imcCategoria.style.color  = cat.color;
  barraIndicador.style.left = `${posicion}%`;

  resultGroup.classList.add("visible");
}

// ── Event Listeners ───────────────────────────────────────────────────────────
btnCalcular.addEventListener("click", calcularIMC);

// Calcular también al presionar Enter en cualquier input
[inputPeso, inputAltura].forEach(input => {
  input.addEventListener("keydown", e => {
    if (e.key === "Enter") calcularIMC();
  });
});