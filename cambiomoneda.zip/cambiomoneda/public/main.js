"use strict";

// ── Tasas de cambio relativas al USD (referencia estática) ─────────────────────
// Actualiza estos valores según necesites
const TASAS = {
  USD: 1,
  MXN: 17.15,
  EUR: 0.92,
  GBP: 0.79,
  JPY: 149.50,
  CHF: 0.90,
  CAD: 1.36,
  AUD: 1.53,
  CNY: 7.24,
  BRL: 4.97,
  ARS: 865.00,
  COP: 3950.00,
  KES: 129.50,
  UGX: 3780.00,
  INR: 83.10,
  RUB: 90.25,
};

// Símbolo por moneda
const SIMBOLOS = {
  USD: "$",  MXN: "$",  EUR: "€",  GBP: "£",
  JPY: "¥",  CHF: "Fr", CAD: "$",  AUD: "$",
  CNY: "¥",  BRL: "R$", ARS: "$",  COP: "$",
  KES: "KSh",UGX: "USh",INR: "₹",  RUB: "₽",
};

// ── Elementos del DOM ──────────────────────────────────────────────────────────
const inputCantidad    = document.getElementById("cantidad");
const selectOrigen     = document.getElementById("monedaOrigen");
const selectDestino    = document.getElementById("monedaDestino");
const btnConvertir     = document.getElementById("btnConvertir");
const btnSwap          = document.getElementById("btnSwap");
const simboloOrigen    = document.getElementById("simboloOrigen");
const resultadoValor   = document.getElementById("resultadoValor");
const resultadoMoneda  = document.getElementById("resultadoMoneda");
const tasaInfo         = document.getElementById("tasaInfo");

// ── Convertir entre dos monedas usando USD como base ──────────────────────────
function convertir(cantidad, origen, destino) {
  const enUSD = cantidad / TASAS[origen];
  return enUSD * TASAS[destino];
}

// ── Formatear número con separadores y decimales apropiados ───────────────────
function formatearNumero(valor, moneda) {
  // Monedas sin decimales (enteras grandes)
  const sinDecimales = ["JPY", "KES", "UGX", "COP", "ARS", "RUB"];
  const decimales = sinDecimales.includes(moneda) ? 0 : 2;

  return new Intl.NumberFormat("es-MX", {
    minimumFractionDigits: decimales,
    maximumFractionDigits: decimales,
  }).format(valor);
}

// ── Restablecer resultado a estado vacío ──────────────────────────────────────
function resetResultado() {
  resultadoValor.textContent = "—";
  resultadoValor.classList.add("vacio");
  resultadoMoneda.textContent = "";
  resultadoMoneda.classList.remove("visible");
  tasaInfo.textContent = "";
}

// ── Actualizar símbolo del input al cambiar moneda origen ─────────────────────
function actualizarSimbolo() {
  const moneda = selectOrigen.value;
  simboloOrigen.textContent = SIMBOLOS[moneda] || "$";
}

// ── Marcar input con error ────────────────────────────────────────────────────
function marcarError(el) {
  el.classList.remove("input-error");
  void el.offsetWidth;
  el.classList.add("input-error");
  el.addEventListener("input", () => el.classList.remove("input-error"), { once: true });
}

// ── Calcular y mostrar conversión ─────────────────────────────────────────────
function calcularConversion() {
  const cantidad = parseFloat(inputCantidad.value);
  const origen   = selectOrigen.value;
  const destino  = selectDestino.value;

  // Validación
  if (!inputCantidad.value || isNaN(cantidad) || cantidad <= 0) {
    marcarError(inputCantidad);
    resetResultado();
    return;
  }

  // Conversión
  const resultado = convertir(cantidad, origen, destino);
  const simbolo   = SIMBOLOS[destino] || "";

  // Mostrar resultado
  resultadoValor.textContent = `${simbolo} ${formatearNumero(resultado, destino)}`;
  resultadoValor.classList.remove("vacio");

  resultadoMoneda.textContent = destino;
  resultadoMoneda.classList.add("visible");

  // Tasa de referencia: 1 origen = X destino
  const tasa = convertir(1, origen, destino);
  const tasaFormateada = formatearNumero(tasa, destino);
  tasaInfo.textContent = `1 ${origen} = ${simbolo} ${tasaFormateada} ${destino}`;
}

// ── Intercambiar monedas ──────────────────────────────────────────────────────
function intercambiarMonedas() {
  const temporal = selectOrigen.value;
  selectOrigen.value  = selectDestino.value;
  selectDestino.value = temporal;
  actualizarSimbolo();

  // Si ya hay un resultado, recalcular
  if (!resultadoValor.classList.contains("vacio")) {
    calcularConversion();
  }
}

// ── Event Listeners ───────────────────────────────────────────────────────────
btnConvertir.addEventListener("click", calcularConversion);
btnSwap.addEventListener("click", intercambiarMonedas);
selectOrigen.addEventListener("change", actualizarSimbolo);

// Calcular al presionar Enter
inputCantidad.addEventListener("keydown", e => {
  if (e.key === "Enter") calcularConversion();
});

// Inicializar símbolo
actualizarSimbolo();